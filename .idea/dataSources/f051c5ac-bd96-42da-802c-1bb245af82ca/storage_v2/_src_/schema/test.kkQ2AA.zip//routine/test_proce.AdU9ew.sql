create
  definer = root@localhost procedure test_proce()
begin
INSERT T_DEPT VALUE ( CURRENT_TIME,'ttt','www','bbb');
end;

