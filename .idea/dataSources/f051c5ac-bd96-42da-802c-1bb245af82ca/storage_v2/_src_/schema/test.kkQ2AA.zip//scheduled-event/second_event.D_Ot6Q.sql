create definer = root@localhost event second_event on schedule
  every '1' SECOND
    starts '2019-03-22 14:46:39'
  on completion preserve
  disable
  do
  call test_proce();

